#include<bits/stdc++.h>
#include<graphics.h>
#include<conio.h>
using namespace std;
main() {
   int gd = DETECT, gm;

   initgraph(&gd, &gm, "C:\\TC\\BGI");
    //void circle(int x, int y, int radius);
   circle(100, 100, 50);

   getch();

   closegraph();

   return 0;
}
