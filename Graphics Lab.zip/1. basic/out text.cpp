#include<bits/stdc++.h>
#include<graphics.h>
#include<conio.h>
using namespace std;
main()
{
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "C:\\TC\\BGI");
    outtext("To display text at a particular position on the screen use outtextxy"); getch();
    closegraph();
    return 0;
}
