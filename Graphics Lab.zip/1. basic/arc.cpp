#include<bits/stdc++.h>
#include<graphics.h>
#include<conio.h>
using namespace std;
int main(){
    int gd = DETECT,gm;
    initgraph(&gd,&gm,"");
    //void arc(int x, int y, int startAngle, int endAngle, int sweep);
    //sweep is radius
    sweep=radius
    arc(100,100,0,135,50);
    getchar();
    closegraph();
    return 0;
}
